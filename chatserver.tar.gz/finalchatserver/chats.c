#include "Mheader.h"

int main()
{
	int sock;
	createsocket(&sock);

	int activenum=0;
	int currentadd=0;

	csock arr[100];

	fd_set rset,wset;
	FD_ZERO(&rset);
	FD_ZERO(&wset);
	FD_SET(sock,&rset);
	FD_SET(sock,&wset);
	fd_set tempset;
	fd_set tempw;
	int i;
	int req,flag=0;

	while(1)
	{
		tempset=rset;
		tempw=wset;

	//	printf("Active Connections: %d\n",activenum);

		int s=select(FD_SETSIZE,&tempset,&wset,NULL,NULL);

		if(s==-1) perror("Select: ");
		else
		{
			if(FD_ISSET(sock,&tempset))
			{
				printf("New Connection: ");
				
				arr[currentadd].flaggreet=1;
				arr[currentadd].flagrec=0;
				arr[currentadd].len=sizeof(struct sockaddr_in);
				arr[currentadd].sock=accept(sock,(struct sockaddr*)&arr[currentadd].addr,&arr[currentadd].len);
	
				FD_SET(arr[currentadd].sock,&rset);
				FD_SET(arr[currentadd].sock,&wset);

				printf("%s: %d\n", inet_ntoa(arr[currentadd].addr.sin_addr),arr[currentadd].addr.sin_port);				
				currentadd++;
				activenum++;
			}

			else
			{
				for(i=0;i<currentadd;i++)
				{
					if(FD_ISSET(arr[i].sock,&tempset))
					{
						char buf[100]="";
						if(read(arr[i].sock,buf,100))
						{
							if(arr[i].flagname!=1)
							{
								arr[i].flagname=1;
								strcpy(arr[i].name,buf);
								arr[i].flaggreet=0;
								int j;
								char msg[100];
								sprintf(msg,"%s is now online\n",buf);
								for(j=0;j<currentadd;j++)
								{
									if(j==i) continue;

									write(arr[j].sock,msg,sizeof(msg));
								}
							}

							else
								if(strcmp(buf,"update")==0)
								{
									printf("Update Request\n");
									req=2;
								}
								
							if(req==2)
							{
								//printf("UpdaterBP\n");
								req=0;
								printf("%d\n",currentadd);
								displaygreeting(arr,currentadd,i);
							}
							
							else 
							{
								printf("%s: %d --- %s\n",inet_ntoa(arr[i].addr.sin_addr),arr[i].addr.sin_port,buf);
								char newmsg[100];
								strcpy(newmsg,buf+2);
								printf("%s %d\n",newmsg,buf[0]-'0');
								//printf("%s\n",arr[arr[i].rsock].name);	
								char name[100];
								strcpy(name,arr[i].name);
								strcat(name,": ");
								strcat(name,newmsg);
								write(arr[buf[0]-'0'].sock,name,100);
							}
						}

						else
						{
							FD_CLR(arr[i].sock,&rset);
							arr[i].sock=0;
							activenum--;
						}
					}

					else
					{
						if(FD_ISSET(arr[i].sock,&tempw))
						{
							if(arr[i].flaggreet!=1)
							{
								arr[i].flaggreet=1;
								displaygreeting(arr,currentadd,i);
							}
						}
					}
				}
			}
		}
	}
	return 0;
}