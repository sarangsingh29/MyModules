#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

void getgreeting(int);
void getInstructions();

int main()
{
	int t;
	srand(t);
	int k=rand()%10000;
	int csock;
	csock=socket(AF_INET,SOCK_STREAM,0);
	int port;
/*	
	int f=open("servport",O_RDWR);
	read(f,&port,sizeof(int));
	close(f);
*/
	//printf("%d %d\n",port,k);
	

	struct sockaddr_in caddr;
	caddr.sin_port=k;
	caddr.sin_family=AF_INET;
	caddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	//int b=bind(csock,(struct sockaddr*)&caddr,sizeof(caddr));
	//if(b==-1) perror("BIND: ");



	struct sockaddr_in addr;

	printf("Enter the server-ip and server-port: ");
	char serip[100];
	scanf("%s %d",serip,&port);

	while(1)
	{
		addr.sin_family=AF_INET;
		addr.sin_addr.s_addr=inet_addr(serip);
		addr.sin_port=port;

		int c=connect(csock,(struct sockaddr*)&addr,sizeof(addr));
		if(c==-1)
		{
			perror("CONNECT: ");
			printf("\nEnter again: ");
			scanf("%s %d",serip,&port);
			continue;
		}
		else
		{
			printf("Socket connected\n");
			break;
		}
	}

	char msg[100];
	char name[100];
	printf("Your Name: ");
	scanf("%s",name);
	write(csock,name,100);
	printf("\n\n");


	getgreeting(csock);
	
	getInstructions();

	fd_set rset;
	FD_ZERO(&rset);
	FD_SET(0,&rset);
	FD_SET(csock,&rset);

	fd_set wset;
	FD_ZERO(&wset);
	FD_SET(csock,&wset);

	fd_set tempw, tempr;
	int flag;
	while(1)
	{
		tempw=wset;
		tempr=rset;

		int s=select(FD_SETSIZE,&tempr,&tempw,NULL,NULL);
		if(s==-1) perror("SELECT: ");
		else
		{
			if(FD_ISSET(csock,&tempr))
			{
				if(flag==1)
				{
					getgreeting(csock);
					flag=0;
				}

				else
					if(read(csock,msg,100))
					{
						printf("%s\n\n",msg);
					}
					else
					{
						return 0;
					}
			}

			if(FD_ISSET(0,&tempr))
			{
				//printf("Term\n");
				char buf[100];
				scanf("%s",buf);

				if(strcmp(buf,"update")==0) flag=1;
				if(strcmp(buf,"clear")==0)
				{
					system("clear");
					continue;
				}
				if(strcmp(buf,"ins")==0)
				{
					getInstructions();
					continue;
				}
				
				write(csock,buf,100);
			}
		}

	}
	//printf("afterwhile\n");
	
	
	//scanf("%s",msg);
	//write(csock,msg,100);

	return 0;
}

void getgreeting(int sock)
{

	char msg[100];
	int r;
	int i=0;
	while((r=read(sock,msg,100))!=0)
	{
		if(strcmp(msg,"over")==0)
		{
			printf("\n");
			break;
		}
		i++;
		printf("%s\n",msg);
		//scanf("%s",msg);
	}
}

void getInstructions()
{
	printf("\t\t\t\t\tType \"update\" to get online users\n");
	printf("\t\t\t\t\tType \"clear\" to clear the screen\n");
	printf("\t\t\t\t\tType \"ins\" to repeat instructions\n\n");
}
