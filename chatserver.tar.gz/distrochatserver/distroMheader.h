#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

struct client_socket
{
	int sock;
	int flagname, flaggreet, flagrec;
	struct sockaddr_in addr;
	int len;
	int rsock;
	char name[100];
};

#define csock struct client_socket

void createsocket(int* sock)
{
	/*int f=open("servport",O_RDWR);
	int port;
	read(f,&port,sizeof(int));
	port+=1;
	port%=10000;
	lseek(f,SEEK_SET,0);
	write(f,&port,sizeof(int));
	close(f);

	printf("%d\n",port);*/

	int port;
	char servip[100];

	printf("Enter the server-ip and server-port: ");
	scanf("%s %d",servip,&port);

	while(1)
	{
		(*sock)=socket(AF_INET,SOCK_STREAM,0);
		struct sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=port;
		addr.sin_addr.s_addr=inet_addr(servip);

		int b=bind((*sock),(struct sockaddr*)&addr,sizeof(addr));
		if(b==-1)
		{
			perror("BIND: ");
			printf("\nEnter again: ");
			scanf("%s %d",servip,&port);
		}
		else
		{
			printf("Socket ready\n");
			break;
		}
	}	
	listen((*sock),5);
}


void displaygreeting(csock arr[], int num, int i)
{
	char buf[100]="\nWelcome ";
	strcat(buf,arr[i].name);
	write(arr[i].sock,buf,100);
	strcpy(buf,"Online Users");
	write(arr[i].sock,buf,100);

	int j=0;
	for(j=0;j<num;j++)
	{
		if(arr[j].sock==0 || j==i) continue;

		sprintf(buf,"%s: %s %d %d",arr[j].name,inet_ntoa(arr[j].addr.sin_addr),arr[j].addr.sin_port,j);
		printf("%s\n\n",buf);
		write(arr[i].sock,buf,100);
	}
	strcpy(buf,"over");
	write(arr[i].sock,buf,100);
}
